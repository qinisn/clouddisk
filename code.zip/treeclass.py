#!/usr/bin/env python
# coding: utf-8


from xgboost.core import DMatrix
import xgboost.core as xgb_core
import pandas as pd
import numpy as np
import copy
import xgboost as xgb
from dataclasses import dataclass
from typing import Union, Dict, List
import os
import warnings
import logging
import math
import json
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_auc_score
import time
from utils import *
from infoclass import *
from config import *

warnings.filterwarnings("ignore")


class Homotree:
    def __init__(
        self,
        data, 
        label_key,
        binning,
        params,
        tree_id,
        nodes: List[Node] = None, 
        cur_layer_node = None, 
        cur_layer_datas = None

    ):
        self.data = data
        self.label_key = label_key
        self.header = [i for i in self.data.columns if i not in [self.label_key, 'g', 'h'] ]
        self.bin_split_points = binning
        self.iter_round = tree_id
        self.group_id = 0
        self.tree_id = tree_id

        self.max_depth = params.max_depth
        self.min_sample_split = params.min_sample_split
        self.min_impurity_split = params.gamma
        self.min_leaf_node = params.min_leaf_node
        self.max_split_nodes = params.max_split_nodes
        self.feature_importance_type = params.importance_type
        self.objective = params.objective
        self.learning_rate = params.eta
        self.use_missing = params.use_missing
        self.min_child_weight = params.min_child_weight
        self.num_class = params.num_class
        self.reg_lambda = params.reg_lambda
        self.reg_alpha = params.reg_alpha
        self.decimal = params.decimal

        self.criterion = Criterion(reg_lambda = self.reg_lambda, reg_alpha = self.reg_alpha, decimal = self.decimal)
        self.feature_importance = {}
        self.round_cal_root_node = 0
        self.round_fit = 0
        if nodes is not None:
            self.tree_node = nodes
            self.tree_node_num = len(nodes)
            if cur_layer_node is None or cur_layer_datas is None:
                logging.warning("layer information missing")
        else:
            self.cal_root_node()
        self.xgb_version = list(map(int, xgb.__version__.split(".")))

        



        
    def cal_root_node(self):
        g_sum = self.data['g'].sum() 
        h_sum = self.data['h'].sum() 

        '''
        通信步骤：
        传送 g_sum, h_sum
        接收 total_g_sum = total_g_sum, total_h_sum = total_h_sum

        变量：
        g_sum：本地的grad和
        h_sum：本地的hess和
        total_g_sum：聚合的grad和
        total_h_sum：聚合的hess和
        '''

        dict = {"g_sum":g_sum, "h_sum":h_sum}
        post_message(dict, 'rootnode', self.round_cal_root_node)
        dict = get_message('rootnode', self.round_cal_root_node)
        total_g_sum = dict['total_g_sum']
        total_h_sum = dict['total_h_sum']
        self.round_cal_root_node += 1
        
        
        self.tree_node = []
        self.cur_layer_node = [Node(
            id=0,
            sum_grad=total_g_sum,
            sum_hess=total_h_sum,
            weight=self.criterion.node_weight(total_g_sum, total_h_sum),
            sample_num=len(self.data),
        )] 
        self.cur_layer_datas = [list(self.data.index)]
        self.tree_node_num = 1

    
    def bin_df(self):
        binned_df = copy.deepcopy(self.data)
        for id, binning in enumerate(self.bin_split_points):
            bin_column_name = f'{self.header[id]}_bin'
            binned_df[bin_column_name] = pd.cut(
                binned_df[self.header[id]], 
                right = False,
                bins=binning, 
                labels = [i for i in range(len(binning)-1)]
            ).astype('Int64')
            binned_df.drop(self.header[id], axis=1, inplace = True)

        return binned_df
    
    
    

    def local_gh(self, data):
        hist_node = []
        for node_id in range(len(self.cur_layer_node)):
            '''
            print(self.cur_layer_datas[party_id][node_id])
            print(data[party_id])
            print(data[party_id].loc[self.cur_layer_datas[party_id][node_id],:])
            '''
            cur_data_frame = data.loc[self.cur_layer_datas[node_id],:]
            hist_ft = []
            for ft in range(len(self.header)):
                g_bin = cur_data_frame.groupby(self.header[ft]+'_bin')['g'].sum().reindex(range(len(self.bin_split_points[0])-1), fill_value=0).tolist()
                g_bin.append(cur_data_frame.loc[cur_data_frame[self.header[ft]+'_bin'].isnull(), 'g'].sum())
                g_bin = cumul_list(g_bin)
                h_bin = cur_data_frame.groupby(self.header[ft]+'_bin')['h'].sum().reindex(range(len(self.bin_split_points[0])-1), fill_value=0).tolist()
                h_bin.append(cur_data_frame.loc[cur_data_frame[self.header[ft]+'_bin'].isnull(), 'h'].sum())
                h_bin = cumul_list(h_bin)
                cnt_bin = cur_data_frame[self.header[ft]+'_bin'].value_counts().reindex(range(len(self.bin_split_points[0])-1), fill_value=0).values.tolist()
                cnt_bin.append(cur_data_frame[self.header[ft]+'_bin'].isna().sum())
                cnt_bin = cumul_list(cnt_bin)
                hist_ft.append([[*i] for i in zip(g_bin, h_bin, cnt_bin)])
            hist_node.append(hist_ft)
        return hist_node

    def global_gh(self, local_hist):
        return sum([np.array(party) for party in local_hist]).tolist()


    def find_split_point(self, histograms):
        # histograms 节点 特征 箱 数值
        splitinfo = []
        for histogram in histograms:
            best_gain = self.min_impurity_split
            best_fid = 0
            best_bid = 0
            best_sum_grad_l = 0
            best_sum_hess_l = 0
            best_sample_cnt = 0
            missing_dir = -1
            for fid in range(len(histogram)): 
                bin_num = len(histogram[fid])
                # The last bucket stores the sum of all nodes(cumsum from left)
                sum_grad = histogram[fid][bin_num - 1][0]
                sum_hess = histogram[fid][bin_num - 1][1]
                node_cnt = histogram[fid][bin_num - 1][2]
                if node_cnt < self.min_sample_split:
                    break
    
                # The last bucket does not participate in the split point search, so bin_num-1
                for bid in range(bin_num - 1):
                    # left gh
                    sum_grad_l, sum_hess_l, node_cnt_l = histogram[fid][bid]
    
                    # right gh
                    sum_grad_r = sum_grad - sum_grad_l
                    sum_hess_r = sum_hess - sum_hess_l
                    node_cnt_r = node_cnt - node_cnt_l
                    logging.debug(
                        f"split::fid={fid} bid={bid} sum_of_grad_l:{sum_grad_l},sum_of_hess_l={sum_hess_l} ,"
                        f"node_cnt_l={node_cnt_l}"
                    )
    
                    gain = self.criterion.split_gain(
                        (sum_grad, sum_hess),
                        (sum_grad_l, sum_hess_l),
                        (sum_grad_r, sum_hess_r),
                    )


                    if gain > self.min_impurity_split and gain > best_gain:
                        best_gain = gain
                        best_fid = fid
                        best_bid = bid
                        best_sum_grad_l = sum_grad_l
                        best_sum_hess_l = sum_hess_l
                        best_sample_cnt = node_cnt_l
                        missing_dir = 1
    
                    # handle missing value: dispatch to left sub tree
                    if self.use_missing:
                        sum_grad_l += histogram[fid][-1][0] - histogram[fid][-2][0]
                        sum_hess_l += histogram[fid][-1][1] - histogram[fid][-2][1]
                        node_cnt_l += histogram[fid][-1][2] - histogram[fid][-2][2]
    
                        sum_grad_r -= histogram[fid][-1][0] - histogram[fid][-2][0]
                        sum_hess_r -= histogram[fid][-1][1] - histogram[fid][-2][1]
                        node_cnt_r -= histogram[fid][-1][2] - histogram[fid][-2][2]
    
                        # If the left side is gain more, point missing_DIR to the left
                        # and update the optimal split information
                        if self._check_sample_num(node_cnt_l, node_cnt_r) and self._check_min_child_weight(sum_hess_l, sum_hess_r):
                            gain = self.criterion.split_gain(
                                (sum_grad, sum_hess),
                                (sum_grad_l, sum_hess_l),
                                (sum_grad_r, sum_hess_r),
                            )
                            if gain > self.min_impurity_split and gain > best_gain:
                                best_gain = gain
                                best_fid = fid
                                best_bid = bid
                                best_sum_grad_l = sum_grad_l
                                best_sum_hess_l = sum_hess_l
                                missing_dir = -1
                                best_sample_cnt = node_cnt_l
                    
    
            splitinfo.append(SplitInfo(
                best_fid=best_fid,
                best_bid=best_bid,
                gain=best_gain,
                sum_grad=best_sum_grad_l,
                sum_hess=best_sum_hess_l,
                missing_dir=missing_dir,
                sample_count=best_sample_cnt,
            ))
        return splitinfo


                
            
    def update_tree(
        self,
        cur_to_split: List[Node],
        split_info: List[SplitInfo],
        cur_data_frames_index: List[pd.DataFrame],
        cur_data_frames
    ):
        """Tree update function
        Args:
            cur_to_split: List of nodes to be split
            split_info: Global optim split info
            cur_data_frames_list: List of dataframe index in each node
        Returns:
            next_layer_node: List of nodes to be evaluated in the next iteration
            next_layer_data: List of data to be evaluated in the next iteration

        """
        logging.debug(
            'updating tree_node, cur layer has {} node'.format(len(cur_to_split))
        )
        next_layer_node, next_layer_data = [], []
        

        assert len(cur_to_split) == len(
            split_info
        ), "Num of nodes and split_info must have same length"

        for idx in range(len(cur_to_split)):
            if (
                split_info[idx].best_fid is None
                or split_info[idx].gain <= self.min_impurity_split
            ):
                cur_to_split[idx].is_leaf = True
                self.tree_node.append(cur_to_split[idx])
                continue

            cur_data_frame_index = cur_data_frames_index[idx]
            cur_data_frame = cur_data_frames.loc[cur_data_frame_index,:]

            best_split_col = self.header[split_info[idx].best_fid]
            
            best_split_bin = self.bin_split_points[split_info[idx].best_fid][  
                split_info[idx].best_bid
            ]
            
            best_split_bin = split_info[idx].best_bid
            

            sum_grad = cur_to_split[idx].sum_grad
            sum_hess = cur_to_split[idx].sum_hess

            cur_to_split[idx].fid = split_info[idx].best_fid
            cur_to_split[idx].bid = split_info[idx].best_bid
            cur_to_split[idx].missing_dir = split_info[idx].missing_dir  #deal with missing values

            p_id = cur_to_split[idx].id
            l_id, r_id = self.tree_node_num , self.tree_node_num + 1
            cur_to_split[idx].left_nodeid, cur_to_split[idx].right_nodeid = l_id, r_id
            self.tree_node_num += 2

            l_g, l_h = split_info[idx].sum_grad, split_info[idx].sum_hess
            # create new left node and new right node
            left_data = cur_data_frame[cur_data_frame[best_split_col+'_bin'] <= best_split_bin].index.tolist()
            
            left_node = Node(
                id=l_id,
                sum_grad=l_g,
                sum_hess=l_h,
                weight=self.criterion.node_weight(l_g, l_h) * self.learning_rate,#node_weight
                parent_nodeid=p_id,
                sibling_nodeid=r_id,
                is_left_node=True,
                sample_num=len(left_data),
            )
            right_data = cur_data_frame[cur_data_frame[best_split_col+'_bin'] > best_split_bin].index.tolist()
            
            
            right_node = Node(
                id=r_id,
                sum_grad=sum_grad - l_g,
                sum_hess=sum_hess - l_h,
                weight=self.criterion.node_weight(sum_grad - l_g, sum_hess - l_h)
                * self.learning_rate,
                parent_nodeid=p_id,
                sibling_nodeid=l_id,
                is_left_node=False,
                sample_num=len(right_data),
            )

            next_layer_node.append(left_node)
            next_layer_data.append(left_data)

            next_layer_node.append(right_node)
            next_layer_data.append(right_data)
            cur_to_split[idx].loss_change = split_info[idx].gain
            self.tree_node.append(cur_to_split[idx])

            self.update_feature_importance(split_info[idx])  

        return next_layer_node, next_layer_data
            

    def update_feature_importance(self, split_info):
        """Calculate feature importance
        default split count
        Args:
            split_info: Global optimal splitting information calculated from histogram
        """
        inc_split, inc_gain = 1, split_info.gain

        fid = split_info.best_fid

        if fid not in self.feature_importance:
            self.feature_importance[fid] = FeatureImportance(
                0, 0, self.feature_importance_type
            )

        self.feature_importance[fid].add_split(inc_split)
        if inc_gain is not None:
            self.feature_importance[fid].add_gain(inc_gain)


    def fit(self):
        binned_df = self.bin_df()
        for i in range(self.max_depth):
            local_hist = self.local_gh(binned_df)

            '''
            通信步骤：
            传送 local_hist
            接收 splitinfo = splitinfo

            变量：
            local_hist：本地的直方图，传送至服务端聚合计算分裂信息
            splitinfo：分裂信息，根据该信息分裂树的下一层
            '''
            dict = {"local_hist":convert_to_float(local_hist)}
            post_message(dict, f'fit_{self.tree_id}', self.round_fit)
            dict = get_message(f'fit_{self.tree_id}', self.round_fit)
            self.round_fit += 1
            splitinfo = [SplitInfo(**item) for item in dict['splitinfo']]


            self.cur_layer_node, self.cur_layer_datas = self.update_tree(
                                                                        self.cur_layer_node, 
                                                                        splitinfo, 
                                                                        self.cur_layer_datas,
                                                                        binned_df
            )
            if i == self.max_depth -1:
                for node in self.cur_layer_node:
                    node.is_leaf = True
                    self.tree_node.append(node)

        self.convert_bin_to_real()
        

    def convert_bin_to_real(self):
        """convert bid to real value"""
        for node in self.tree_node:
            if not node.is_leaf:
                node.bid = self.bin_split_points[node.fid][node.bid+1]



    def init_xgboost_model(self, model_path: str):
        """Init standard xgboost model
        Args:
            model_path: model path
        """
        model = {}

        json_objection = {}
        if self.objective == "reg:squarederror" or self.objective == "":
            json_objection["objective"] = {
                "name": self.objective,
                "reg_loss_param": {"scale_pos_weight": "1"},
            }
        elif self.objective == "binary:logistic" or self.objective == "reg:logistic":
            json_objection["objective"] = {
                "name": self.objective,
                "reg_loss_param": {"scale_pos_weight": "1"},
            }
        elif self.objective == "multi:softmax" or self.objective == "multi:softprob":
            json_objection["objective"] = {
                "name": self.objective,
                "softmax_multiclass_param": {"num_class": str(self.num_class)},
            }
        else:
            raise Exception(f"Unknow objection:{self.objective}")

        model["learner"] = {
            "attributes": {},
            "feature_names": self.header,
            "feature_types": ['float' for i in self.header],
            "gradient_booster": {
                "model": {
                    "gbtree_model_param": {"num_trees": 0, "size_leaf_vector": 0},
                    "tree_info": [],
                    "trees": [],
                },
                "name": "gbtree",
            },
            "learner_model_param": {
                "base_score": "5E-1",
                "num_class": str(self.num_class),
                "num_feature": str(len(self.header)),
            },
        }
        model["learner"]["objective"] = json_objection["objective"]
        model["version"] = self.xgb_version

        with open(model_path, "w") as dump_f:
            json.dump(model, dump_f)

    def save_xgboost_model(self, model_path: str, tree_nodes: List[Node]):
        """Transform tree info to standard xgboost model
        ref: https://xgboost.readthedocs.io/en/latest/dev/structxgboost_1_1TreeParam.html#aab8ff286e59f1bbab47bfa865da4a107
        Args:
            model_path: model path
            tree_nodes: federate decision tree internal model
        Returns:
            update standard xgboost model on the model path
        """
        with open(model_path, 'r') as load_f:
            json_model = json.load(load_f)
        tree_param = {
            "base_weights": [],
            "categories": [],
            "categories_nodes": [],
            "categories_segments": [],
            "categories_sizes": [],
            "default_left": [],
            "id": self.tree_id,
            "left_children": [],
            "loss_changes": [],
            "parents": [],
            "right_children": [],
            "split_conditions": [],
            "split_indices": [],
            "split_type": [],
            "sum_hessian": [],
            "tree_param": {
                "num_deleted": "0",
                "num_feature": str(len(self.header)),
                "num_nodes": str(len(tree_nodes)),
                "size_leaf_vector": "0",
            },
        }
        for node in tree_nodes:
            tree_param["base_weights"].append(
                node.weight if node.weight is not None else 0e0
            )
            tree_param["default_left"].append(1 if node.missing_dir == -1 else 0)
            tree_param["left_children"].append(
                node.left_nodeid if node.left_nodeid is not None else -1
            )
            tree_param["loss_changes"].append(node.loss_change)
            tree_param["parents"].append(
                node.parent_nodeid if node.parent_nodeid is not None else -1
            )
            tree_param["right_children"].append(
                node.right_nodeid if node.right_nodeid is not None else -1
            )
            tree_param["split_conditions"].append(
                node.bid if node.bid is not None else node.weight  
            )
            tree_param["split_indices"].append(node.fid if node.fid is not None else 0)
            tree_param["split_type"].append(0)
            tree_param["sum_hessian"].append(node.sum_hess)

        json_model["learner"]["attributes"]["best_iteration"] = str(self.iter_round)
        json_model["learner"]["attributes"]["best_ntree_limit"] = str(
            self.iter_round + 1
        )

        json_model["learner"]["gradient_booster"]["model"]["tree_info"].append(
            self.group_id
        )
        json_model["learner"]["gradient_booster"]["model"]["trees"].append(tree_param)
        json_model["learner"]["gradient_booster"]["model"]["gbtree_model_param"][
            "num_trees"
        ] = str(
            int(
                json_model["learner"]["gradient_booster"]["model"][
                    "gbtree_model_param"
                ]["num_trees"]
            )
            + 1
        )
        json_model["learner"]["gradient_booster"]["model"]["gbtree_model_param"][
            "size_leaf_vector"
        ] = str(
            json_model["learner"]["gradient_booster"]["model"]["gbtree_model_param"][
                "size_leaf_vector"
            ]
        )
        with open(model_path, "w") as dump_f:
            json.dump(json_model, dump_f, ensure_ascii=False)



class Fedbooster:

    def __init__(
        self,
        params: Dict = None,
        model_file: Union[str, os.PathLike, xgb_core.Booster, bytearray] = None,
        ):

        self.n_estimator = params.get('n_estimators', 5)
        self.bin_num = params.get('bin_num', 10)
        self.model_path = params.get('model_path', 'xgb.json')
        self.params = params
        if isinstance(model_file, xgb_core.Booster):
            self.booster = model_file
        else:
            self.model_file = model_file
        self.tree_param = TreeParam(
            max_depth=params['max_depth'] if 'max_depth' in params else 3,
            eta=params['eta'] if 'eta' in params else 0.3,
            objective=params['objective'],
            verbosity=params['verbosity'] if 'verbosity' in params else 0,
            tree_method=params['tree_method'] if 'tree_method' in params else 'hist',
            reg_lambda=params['lambda'] if 'lambda' in params else 0.1,
            reg_alpha=params['alpha'] if 'alpha' in params else 0.0,
            gamma=params['gamma'] if 'gamma' in params else 1e-4,
            colsample_bytree=(
                params['colsample_bytree'] if 'colsample_bytree' in params else 1.0
            ),
            colsample_byleval=(
                params['colsample_bylevel'] if 'colsample_bylevel' in params else 1.0
            ),
            base_score=params['base_score'] if 'base_score' in params else 0.5,
            random_state=params['random_state'] if 'random_state' in params else 1234,
            num_parallel=params['n_thread'] if 'n_thread' in params else None,
            subsample=params['subsample'] if 'subsample' in params else 1.0,
            decimal=params['decimal'] if 'decimal' in params else 10,
            num_class=params['num_class'] if 'num_class' in params else 0,
        )

        self.round_binning = 0
        self.round_eval = 0


        
    def binning(self, data):
        headers = [i for i in data.columns if i != self.params.get('label_key', 'label') ]
        binning = {}
        data_num = data.shape[0]
        '''
        通信步骤：
        传送 data_num
        
        变量：
        data_num：本地样本数量
        '''
        dict = {"data_num":data_num}
        post_message(dict, 'data_num', self.round_binning)
        self.round_binning += 1
        
        sorted = {ft: data[ft].sort_values() for ft in headers}
        missing_count = {ft: int(sorted[ft].isnull().sum()) for ft in headers}
        is_bool = {ft: data[ft].dtype.kind in 'b' for ft in headers}
        '''
        通信步骤：
        传送 missing_count, is_bool
        接收 split_points = split_points,converge = converge
        while not converge:
            pos = [find_positoin(sorteds[ind], i[0]) for i in split_points]
            传输 pos
            接收 split_points = split_points, converge = converge
    
        
        变量：
        missing_count：本特征的缺失值数量
        is_bool：本特征是否是布尔值
        converge：迭代是否收敛
        split_points：需要查询位置的分割点
        pos:split_points中各查询点的位置
        '''
        dict = {"missing_count": missing_count, "is_bool":is_bool}
        post_message(dict, 'missing', self.round_binning)
        self.round_binning += 1
        converge = 0
        while 1:
            dict = get_message('split_points', self.round_binning)
            split_points ,converge= dict['split_points'], dict['converge']
            if False not in converge.values():
                self.round_binning += 1
                break
            pos = {}
            for ft in converge:
                if converge[ft]:
                    continue
                pos[ft] = [int(find_positoin(sorted[ft], i[0])) for i in split_points[ft]]
            dict = {'pos': pos}
            post_message(dict, 'split_points', self.round_binning)
            self.round_binning += 1
        
        '''
        通信步骤：
        接收 binning = binning
        self.binning = binning_to_list(binning)
        
        变量
        binning：最终分箱结果
        '''
        dict = get_message('binning', self.round_binning)
        self.round_binning += 1
        binning = dict['binning']
        self.binning = binning_to_list(binning)

    
    def get_gh(self, data):
        if 'g' in data.columns:
            dtrain = to_DMatrix(data.drop(['g', 'h'], axis = 1), self.params.get('label_key', 'label'))
        else:
            dtrain = to_DMatrix(data, self.params.get('label_key', 'label'))

        preds = self.booster.predict(dtrain, output_margin=True, training=True)

        labels = dtrain.get_label()
        preds = 1.0 / (1.0 + np.exp(-preds))
        grad = (preds - labels).astype(np.float64)
        hess = (preds * (1.0 - preds)).astype(np.float64)

        data['g'] = grad
        data['h'] = hess  




    def save_model(self, fname: Union[str, os.PathLike]):
        """Save the model to a file.

        Attributes:
            fname : string or os.PathLike, model path, if the suffix is json, store the model in json format

        """
        if isinstance(fname, (str, os.PathLike)):  # assume file name
            fname = os.fspath(os.path.expanduser(fname))
            xgb_core._check_call(
                xgb_core._LIB.XGBoosterSaveModel(self.handle, xgb_core.c_str(fname))
            )
        else:
            raise TypeError("fname must be a string or os PathLike")

    def build(self, data, label_key):
        n_ite = 0
        print('*begin binning data')
        self.binning(data) 
        
        dtrain = to_DMatrix(data, label_key)  

        self.booster = xgb_core.Booster(
            params=self.params, cache=[dtrain], model_file=self.model_file
        )
        gh_data = copy.deepcopy(data)
        while n_ite < self.n_estimator:
            print(f'*begin build {n_ite} tree')
            self.get_gh(gh_data)
            decision_tree = Homotree(gh_data, label_key, self.binning, self.tree_param, n_ite)
            decision_tree.fit()
            if n_ite == 0:
                decision_tree.init_xgboost_model(self.model_path)
            decision_tree.save_xgboost_model(
                self.model_path, decision_tree.tree_node
            )
            self.booster.load_model(self.model_path)

            #self.booster.predict(to_DMatrix(data[0], self.label_key), output_margin=True, training=True)
            n_ite += 1
            
        self.booster.save_model(self.model_path)

    
    def fed_eval(self, data, label_key, iterange = None):
        print('*' * 30)
        print('here is the evaluation on dataset')
        if iterange is None:
            iterange = (0, self.n_estimator)
        dtrain = to_DMatrix(data, label_key)
        preds = self.booster.predict(dtrain, output_margin=True, iteration_range = iterange)
        labels = dtrain.get_label()
        preds_pro = 1.0 / (1.0 + np.exp(-preds))
        auc = roc_auc_score(labels, preds_pro)
        print("AUC:", auc)
        preds_lab = [1 if i > .5 else 0 for i in preds_pro]
        cm = confusion_matrix(labels, preds_lab)
        print('confusion matrix:')
        print(cm)
        '''
        通信步骤：
        传送 cm
        接收 cm_all
        
        变量
        cm：本地混淆矩阵
        cm_all：全局混淆矩阵
        '''
        dict = {"cm": cm.tolist()}
        post_message(dict, 'eval', self.round_eval)
        dict = get_message('eval', self.round_eval)
        self.round_eval += 1
        cm_all = np.array(dict['cm_all'])
        print('total confusion matrix:')
        print(cm_all)
    
