from utils import *

dict = {}
post_message(dict, 'client', '')
get_message('server', '')