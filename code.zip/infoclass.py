#!/usr/bin/env python
# coding: utf-8


from xgboost.core import DMatrix
import xgboost.core as xgb_core
import pandas as pd
import numpy as np
import copy
import xgboost as xgb
from dataclasses import dataclass
from typing import Union, Dict, List
import os
import warnings
import logging
import math
import json
import time

warnings.filterwarnings("ignore")




class Criterion:
    """
    Attributes:
        reg_lambda: L2 regularization term on weight
        reg_alpha: L1 regularization term on weight
        decimal: truncate parms
    """

    def __init__(
        self, reg_lambda: float = 0.1, reg_alpha: float = 0, decimal: int = 10
    ):
        assert (
            reg_lambda >= 0
        ), f" value {reg_lambda} for Parameter reg_lambda should be greater equal to 0"
        self.reg_lambda = reg_lambda  # l2 reg
        assert (
            reg_alpha >= 0
        ), f" value {reg_alpha} for Parameter reg_alpha should be greater equal to 0"
        self.reg_alpha = reg_alpha  # l1 reg
        self.decimal = decimal
        logging.debug(
            'splitter criterion setting done: l1 {}, l2 {}'.format(
                self.reg_alpha, self.reg_lambda
            )
        )

    @staticmethod
    def _g_alpha_cmp(gradient: float, reg_alpha: float) -> float:
        """L1 regularization on gradient
        Args:
            gradient: The value of the gradient
            reg_alpha: L1 regularization term
        """
        if gradient < -reg_alpha:
            return gradient + reg_alpha
        elif gradient > reg_alpha:
            return gradient - reg_alpha
        else:
            return 0

    def split_gain(
        self,
        node_sum,
        left_node_sum,
        right_node_sum,
    ) -> float:
        """Calculate split gain
        Args:
            node_sum: After the split, Grad and Hess at this node
            left_node_sum:  After the split, Grad and Hess at the left split point
            right_node_sum: After the split, Grad and Hess at the right split point
        Returns:
            gain: Split gain of this split
        """
        sum_grad, sum_hess = node_sum
        left_node_sum_grad, left_node_sum_hess = left_node_sum
        right_node_sum_grad, right_node_sum_hess = right_node_sum
        gain = (
            self.node_gain(left_node_sum_grad, left_node_sum_hess)
            + self.node_gain(right_node_sum_grad, right_node_sum_hess)
            - self.node_gain(sum_grad, sum_hess)
        )
        return self.truncate(gain, decimal=self.decimal)

    @staticmethod
    def truncate(f, decimal=10):
        """Truncate control precision can reduce training time with early stop"""
        return math.floor(f * 10**decimal) / 10**decimal

    def node_gain(self, sum_grad: float, sum_hess: float) -> float:
        """Calculate node gain
        Args:
            sum_grad: Sum of gradient
            sum_hess: Sum of hessian
        Returns:
            Gain of this node
        """
        if sum_hess < 0:
            return 0.0
        sum_grad, sum_hess = self.truncate(
            sum_grad, decimal=self.decimal
        ), self.truncate(sum_hess, decimal=self.decimal)
        reg_grad = self._g_alpha_cmp(sum_grad, self.reg_alpha)
        gain = reg_grad * reg_grad / (sum_hess + self.reg_lambda)
        return self.truncate(gain, decimal=self.decimal)

    def node_weight(self, sum_grad: float, sum_hess: float) -> float:
        """Calculte node weight
        Args:
            sum_grad: Sum of gradient
            sum_hess: Sum of hessian
        Returns:
            Weight of this node
        """
        return self.truncate(
            -(self._g_alpha_cmp(sum_grad, self.reg_alpha))
            / (sum_hess + self.reg_lambda),
            decimal=self.decimal,
        )



class FeatureImportance(object):
    """Feature importance class

    Attributes:
        main_importance: main importance value, ref main_type
        other_importance: other importance value, ref opposite to main_type
        main_type: type of importance, eg:gain
    """

    def __init__(
        self,
        main_importance: float = 0,
        other_importance: float = 0,
        main_type: str = 'split',
    ):
        
        self.main_importance = main_importance
        self.other_importance = other_importance
        self.main_type = main_type

    def add_gain(self, val: float):
        if self.main_type == 'gain':
            self.main_importance += val
        else:
            self.other_importance += val

    def add_split(self, val: float):
        if self.main_type == 'split':
            self.main_importance += val
        else:
            self.other_importance += val

    def __eq__(self, other):
        return self.main_importance == other.main_importance

    def __lt__(self, other):
        return self.main_importance < other.main_importance

    def __gt__(self, other):
        return self.main_importance > other.main_importance

    def __repr__(self):
        return 'importance type: {}, main_importance: {}, other_importance {}'.format(
            self.main_type, self.main_importance, self.other_importance
        )

    def __add__(self, other):
        assert (
            self.main_type == other.main_type
        ), "Self.main_type and other.main_type must be same! "
        new_importance = FeatureImportance(
            main_type=self.main_type,
            main_importance=self.main_importance + other.main_importance,
            other_importance=self.other_importance + other.other_importance,
        )
        return new_importance


@dataclass()
class TreeParam:
    """Param class, externally exposed interface

    Attributes:
        max_depth :  the max depth of a decision tree.
        eta : learning rate, same as xgb's "eta"
        verbosity : int level of log printing. Valid values are 0 (silent) - 3 (debug).
        objective : Optional[callable , str] objective function, default 'squareloss'
        tree_method: Optional[str] tree type, only support hist
        criterion_method: str split criterion method, default xgboost
        gamma : Optional[float] same as min_impurity_split,minimum gain
        min_child_weight : Optional[float] sum of hessian needed in child nodes
        subsample : Optional[float] subsample rate for rows
        colsample_bytree : Optional[float] subsample rate for columns(by tree)
        colsample_bylevel : Optional[float] subsample rate for columns(by level)
        reg_alpha : Optional[float] L1 regularization term on weights (xgb's alpha).
        reg_lambda : Optional[float] L2 regularization term on weights (xgb's lambda).
        base_score : Optional[float] base score, global bias.
        random_state : Optional[Union[numpy.random.RandomState, int]] Random number seed.
        num_parallel: Optional[int] num of parallel when built tree
        importance_type: Optional[str] importance type, in ['gain','split']
        use_missing: bool whether missing value participate in train
        min_sample_split: minimum sample split of splitting, default to 2
        max_split_nodes: max_split_nodes to parallel finding their splits in a batch
        min_leaf_node: minimum samples on node to split
        decimal: decimal reserved of gain
        num_class: num of class
    """

    max_depth: int = 3
    eta: float = 0.3
    verbosity: int = 0
    objective: Union[callable, str] = None
    tree_method: str = 'hist'
    criterion_method: str = 'xgboost'
    gamma: float = 1e-4
    min_child_weight: float = 1
    subsample: float = 1
    colsample_bytree: float = 1
    colsample_byleval: float = 1
    reg_alpha: float = 0.0
    reg_lambda: float = 0.1
    base_score: float = 0.5
    random_state: int = 1234
    num_parallel: int = None
    importance_type: str = 'split'  # 'split', 'gain'
    use_missing: bool = False
    min_sample_split: int = 2
    max_split_nodes: int = 20
    min_leaf_node: int = 1
    decimal: int = 10
    num_class: int = 0



@dataclass()
class Node:
    """Tree Node

    Attributes:
        id: node id
        fid: feature id
        bid: bucket id
        weight: node weight
        is_leaf: whether this node is leaf
        sum_grad: sum of grad
        sum_hess: sum of hess
        left_nodeid: left node id
        right_nodeid: right node id
        missing_dir: which branch to go when encounting missing value default 1->right
        sample_num: num of data sample
        parent_nodeid: parent nodeid
        is_left_node: is this node if left child of the parent
        sibling_nodeid: sibling node id
        loss_change: the loss change.
    """

    id: int = None
    fid: int = None
    bid: int = None
    weight: float = 0.0
    is_leaf: bool = False
    sum_grad: float = None
    sum_hess: float = None
    left_nodeid: int = -1
    right_nodeid: int = -1
    missing_dir: int = 1
    sample_num: int = 0
    parent_nodeid: int = None
    is_left_node: bool = False
    sibling_nodeid: int = None
    loss_change: float = 0.0

    def __str__(self):
        return (
            f"id{self.id}, fid:{self.fid}, bid:{self.bid}, weight:{self.weight}, sum_grad:{self.sum_grad}, "
            f"sum_hess:{self.sum_hess}, left_node:{self.left_nodeid}, right_node:{self.right_nodeid}, "
            f"sample_num:{self.sample_num}, is_leaf:{self.is_leaf}, loss_change:{self.loss_change}"
        )



@dataclass()
class SplitInfo:
    """Split Info
    Attributes:
        best_fid: best split on feature id
        best_bid: best split on bucket id
        sum_grad: sum of grad
        sum_hess: sum of hess
        gain: split gain
        missing_dir: which branch to go when encounting missing value default 1->right
        sample_count: num of sample after split
    """

    best_fid: int = None
    best_bid: int = None
    sum_grad: float = 0
    sum_hess: float = 0
    gain: float = None
    missing_dir: int = 1
    sample_count: int = -1

    def __str__(self):
        return (
            f"(fid:{self.best_fid}, bid:{self.best_bid}, "
            f"sum_grad:{self.sum_grad}, sum_hess:{self.sum_hess}, gain:{self.gain}, "
            f"missing_dir:{self.missing_dir}, sample_count:{self.sample_count})\n"
        )

    def __repr__(self):
        return self.__str__()



    


