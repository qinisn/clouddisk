POST_FILE_PATH = r'D:\jupyter project\fxgb\test\server'  # 发送文件路径
GET_FILE_PATH = r'D:\jupyter project\fxgb\test\beagle1'  # 接收文件路径
DATA_PATH = r'D:\jupyter project\fxgb\bank_full_edited.csv'  # 读取数据路径
CHECK_TIME = 0.05  # 检测时间间隔
WAITING_TIME = 30  # 等待时间
ORG = 'beagle1'  # 客户端机构名
