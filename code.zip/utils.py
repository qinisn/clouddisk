#!/usr/bin/env python
# coding: utf-8

from xgboost.core import DMatrix
import xgboost.core as xgb_core
import pandas as pd
import numpy as np
import copy
import xgboost as xgb
from dataclasses import dataclass
from typing import Union, Dict, List
import os
import warnings
import logging
import math
import json
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_auc_score
import time
import sys
from config import *

warnings.filterwarnings("ignore")


def to_DMatrix(data, label_key = 'label'):
    if isinstance(data, xgb.DMatrix):
        return data
    features = data.drop([label_key], axis=1)
    label = data[label_key]
    dmatrix = xgb.DMatrix(data=features, label=label, enable_categorical = True)
    
    return dmatrix


def find_positoin(data, value):
    ans = 0
    for i in data:
        if i < value:
            ans += 1
        else:
            break

    return ans


def update_points(tar, glo, points):
    for i in range(len(points)):
        if tar[i] < glo[i]:
            points[i] = [(points[i][0]+points[i][1])/2, points[i][1], points[i][0]]
        elif tar[i] > glo[i]:
            points[i] = [(points[i][0]+points[i][2])/2, points[i][0], points[i][2]]

    return points



def diff(a, b):
    return max([abs(x-y) for x, y in zip(a,b)])




def convert_to_list(original_dict):
    keys = list(original_dict.keys())
    sorted_keys = sorted(keys)
    return [original_dict[key] for key in sorted_keys]


def cumul_list(x):
    return [sum(x[:(i+1)]) for i in range(len(x))]



def generate_mock():
    data = {'a':np.random.rand(total_sample_num), 'b':np.random.rand(total_sample_num), 'c':np.random.rand(total_sample_num)}
    data = pd.DataFrame(data)
    data['label'] = data.apply(lambda x: int((x['a']+3*x['b']+9*x['c'])/8), axis = 1)
    for ft in data.columns:
        if ft == 'label':
            continue
        random_index = np.random.choice(data.index, size=round(data.shape[0] * np.random.uniform(.05, .2)), replace=False)  # 生成随机索引
        data.loc[random_index, ft] = np.nan  
    return data




def convert_data(data, label_key = 'y'):
    categorical_columns = data.select_dtypes(include=['object', 'category']).columns
    one_hot_encoded = pd.get_dummies(data, columns=categorical_columns, drop_first = True)
    
    return one_hot_encoded




def binning_to_list(binning):
    return [binning[i] for i in binning.keys()]


def check_timeout(start_time, waiting_time):
    return time.time() - start_time >= waiting_time



def post_message(dict, name, round):
    save_path = os.path.join(POST_FILE_PATH, f'{name}_{ORG}_{round}.json')
    with open(save_path, 'w') as f:
        json.dump(dict, f)
    save_path = os.path.join(POST_FILE_PATH, f'{name}_{ORG}_{round}.json.ok')
    try:
        with open(save_path, 'w') as f:
            pass
    except FileNotFoundError:
        pass
    except Exception as e:
        raise e
    
        
def get_message(name, round):
    load_path = os.path.join(GET_FILE_PATH, f'{name}_{round}.json')
    start_time = time.time()
    waiting_time = WAITING_TIME
    cnt = 0
    while not check_timeout(start_time, waiting_time):
        if cnt > 100:
            print(f'{load_path} not exists')
            cnt = 0
        try:
            with open(load_path, 'r') as f:
                dict = json.load(f)
            return dict
        except:
            time.sleep(CHECK_TIME)
            cnt += 1
    raise FileNotFoundError(f'no {name} file from server')
    


def delete_files_in_dir(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
    files = os.listdir(directory)
    
    for file in files:
        file_path = os.path.join(directory, file)
        if os.path.isfile(file_path):
            os.remove(file_path)


def convert_to_float(lst):
    result = []
    for i in lst:
        if isinstance(i, list):  
            result.append(convert_to_float(i))
        else:
            try:
                result.append(float(i))
            except ValueError:
                raise ValueError(f"无法将元素 '{i}' 转换")
    return result




