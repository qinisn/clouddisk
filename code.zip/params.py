params = {'objective': 'binary:logistic', 'max_depth': 2, 'eta': 0.1, 'n_estimators': 2, 'label_key':'y_yes',
         'scale_pos_weight': 2}