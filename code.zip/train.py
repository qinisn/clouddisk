#!/usr/bin/env python
# coding: utf-8

from xgboost.core import DMatrix
import xgboost.core as xgb_core
import pandas as pd
import numpy as np
import copy
import xgboost as xgb
from dataclasses import dataclass
from typing import Union, Dict, List
import os
import warnings
import logging
import math
import json
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_auc_score
from xgboost import plot_tree
import time
from utils import *
from infoclass import *
from treeclass import *
from config import *
import sys
import importlib
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")
sys.path.append(GET_FILE_PATH)


path = os.path.join(GET_FILE_PATH,'paramfile.py')
if os.path.exists(path):
    ltime = os.path.getmcime(path)
else:
    ltime = 0

while 1:
    try:
        if os.path.exists(path):
            mtime = os.path.getctime(path)
            if mtime > ltime:
                import paramfile
                importlib.reload(paramfile)
                params = paramfile.params
                data = pd.read_csv(DATA_PATH)
                train_data, test_data = train_test_split(data, test_size=0.2, random_state=24)
                train_data = train_data.reset_index(drop=True)
                test_data = test_data.reset_index(drop=True)

                delete_files_in_dir(GET_FILE_PATH)
                delete_files_in_dir(POST_FILE_PATH)
                print('=' * 20)
                print(f'本次训练参数为{params}')

                test_booster = Fedbooster(params)       
                test_booster.build(convert_data(train_data), params['label_key'])    
                test_booster.fed_eval(test_data, params['label_key'])

                ltime = mtime
    except Exception as e:
        print(e)
        if os.path.exists(path):
            ltime = os.path.getctime(path)

    time.sleep(1)


